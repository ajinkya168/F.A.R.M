#! /usr/bin/bash

rosrun agribot distance_sub.py #check stepper_sub.py..there are some changes!

